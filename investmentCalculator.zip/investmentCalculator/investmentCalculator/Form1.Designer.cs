﻿namespace investmentCalculator
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.purchasePrice = new System.Windows.Forms.Label();
			this.downPayment = new System.Windows.Forms.Label();
			this.interestRate = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.purchaseBox = new System.Windows.Forms.TextBox();
			this.downPaymentBox = new System.Windows.Forms.TextBox();
			this.interestRateBox = new System.Windows.Forms.TextBox();
			this.loanTermBox = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.closeBox = new System.Windows.Forms.Button();
			this.amountFinance = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.financeBox = new System.Windows.Forms.TextBox();
			this.monthlyBox = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// purchasePrice
			// 
			this.purchasePrice.AutoSize = true;
			this.purchasePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.purchasePrice.Location = new System.Drawing.Point(125, 54);
			this.purchasePrice.Name = "purchasePrice";
			this.purchasePrice.Size = new System.Drawing.Size(119, 20);
			this.purchasePrice.TabIndex = 0;
			this.purchasePrice.Text = "Purchase Price:";
			// 
			// downPayment
			// 
			this.downPayment.AutoSize = true;
			this.downPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.downPayment.Location = new System.Drawing.Point(64, 133);
			this.downPayment.Name = "downPayment";
			this.downPayment.Size = new System.Drawing.Size(180, 20);
			this.downPayment.TabIndex = 1;
			this.downPayment.Text = "Down Payment Amount:";
			// 
			// interestRate
			// 
			this.interestRate.AutoSize = true;
			this.interestRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.interestRate.Location = new System.Drawing.Point(75, 213);
			this.interestRate.Name = "interestRate";
			this.interestRate.Size = new System.Drawing.Size(169, 20);
			this.interestRate.TabIndex = 2;
			this.interestRate.Text = "Interest Rate (annual):";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(88, 290);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(156, 20);
			this.label2.TabIndex = 3;
			this.label2.Text = "Loan Term (months):";
			// 
			// purchaseBox
			// 
			this.purchaseBox.Location = new System.Drawing.Point(250, 54);
			this.purchaseBox.Name = "purchaseBox";
			this.purchaseBox.Size = new System.Drawing.Size(132, 20);
			this.purchaseBox.TabIndex = 4;
			// 
			// downPaymentBox
			// 
			this.downPaymentBox.Location = new System.Drawing.Point(250, 133);
			this.downPaymentBox.Name = "downPaymentBox";
			this.downPaymentBox.Size = new System.Drawing.Size(132, 20);
			this.downPaymentBox.TabIndex = 5;
			// 
			// interestRateBox
			// 
			this.interestRateBox.Location = new System.Drawing.Point(250, 213);
			this.interestRateBox.Name = "interestRateBox";
			this.interestRateBox.Size = new System.Drawing.Size(132, 20);
			this.interestRateBox.TabIndex = 6;
			// 
			// loanTermBox
			// 
			this.loanTermBox.Location = new System.Drawing.Point(250, 292);
			this.loanTermBox.Name = "loanTermBox";
			this.loanTermBox.Size = new System.Drawing.Size(132, 20);
			this.loanTermBox.TabIndex = 7;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.pictureBox1.Location = new System.Drawing.Point(1, 400);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(799, 50);
			this.pictureBox1.TabIndex = 8;
			this.pictureBox1.TabStop = false;
			// 
			// closeBox
			// 
			this.closeBox.Location = new System.Drawing.Point(638, 415);
			this.closeBox.Name = "closeBox";
			this.closeBox.Size = new System.Drawing.Size(75, 23);
			this.closeBox.TabIndex = 9;
			this.closeBox.Text = "Close";
			this.closeBox.UseVisualStyleBackColor = true;
			this.closeBox.Click += new System.EventHandler(this.closeBox_Click);
			// 
			// amountFinance
			// 
			this.amountFinance.AutoSize = true;
			this.amountFinance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.amountFinance.Location = new System.Drawing.Point(433, 52);
			this.amountFinance.Name = "amountFinance";
			this.amountFinance.Size = new System.Drawing.Size(148, 20);
			this.amountFinance.TabIndex = 10;
			this.amountFinance.Text = "Amount to Finance:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(447, 131);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(134, 20);
			this.label1.TabIndex = 11;
			this.label1.Text = "Monthly Payment:";
			// 
			// financeBox
			// 
			this.financeBox.Location = new System.Drawing.Point(583, 52);
			this.financeBox.Name = "financeBox";
			this.financeBox.ReadOnly = true;
			this.financeBox.Size = new System.Drawing.Size(132, 20);
			this.financeBox.TabIndex = 12;
			// 
			// monthlyBox
			// 
			this.monthlyBox.Location = new System.Drawing.Point(583, 131);
			this.monthlyBox.Name = "monthlyBox";
			this.monthlyBox.ReadOnly = true;
			this.monthlyBox.Size = new System.Drawing.Size(132, 20);
			this.monthlyBox.TabIndex = 13;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(92, 415);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 14;
			this.button1.Text = "Calculate";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.monthlyBox);
			this.Controls.Add(this.financeBox);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.amountFinance);
			this.Controls.Add(this.closeBox);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.loanTermBox);
			this.Controls.Add(this.interestRateBox);
			this.Controls.Add(this.downPaymentBox);
			this.Controls.Add(this.purchaseBox);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.interestRate);
			this.Controls.Add(this.downPayment);
			this.Controls.Add(this.purchasePrice);
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label purchasePrice;
		private System.Windows.Forms.Label downPayment;
		private System.Windows.Forms.Label interestRate;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox purchaseBox;
		private System.Windows.Forms.TextBox downPaymentBox;
		private System.Windows.Forms.TextBox interestRateBox;
		private System.Windows.Forms.TextBox loanTermBox;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button closeBox;
		private System.Windows.Forms.Label amountFinance;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox financeBox;
		private System.Windows.Forms.TextBox monthlyBox;
		private System.Windows.Forms.Button button1;
	}
}

