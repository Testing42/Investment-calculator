﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace investmentCalculator
{
	public partial class Form1 : Form
	{

		int month;
		double time;
		double interest;
		double principal;
		double cost;
		double totalLoan;

		public Form1()
		{
			InitializeComponent();
		}

		private void closeBox_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void button1_Click(object sender, EventArgs e)
		{

				if (int.TryParse(loanTermBox.Text, out month))
				{
					time = Convert.ToDouble(month);	
				}
				else
				{
					MessageBox.Show("Please enter numeric whole number, in months loan term fields.");
				}

				// interest

				if (double.TryParse(interestRateBox.Text, out interest))
				{
					interest = interest / 100 / 12;
				}
				else
				{
					MessageBox.Show("Please enter numeric whole number or decimal, in interest rate field.");
				}

				// downpayment

				if (double.TryParse(downPaymentBox.Text, out cost))
				{

				}
				else
				{
					MessageBox.Show("Please enter numeric whole number or decimal, in down payment field");
				}

				// Purchase Price

				if (double.TryParse(purchaseBox.Text, out principal))
				{
					totalLoan = principal - cost;
					financeBox.Text = totalLoan.ToString("C");
				}
				else
				{
					MessageBox.Show("Please enter numeric whole number or decimal, in Purchase Price.");
				}

				double monthlyPayment = (interest * totalLoan) * (Math.Pow(1 + interest, time) / (Math.Pow(1 + interest, time) - 1));
				monthlyBox.Text = monthlyPayment.ToString("C");
		}
	}
}
